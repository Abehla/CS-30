
public class Car {
	private int fuelEconomyCity, fuelEconomyHwy;
	private int seatingCapacity;
	private double cargoVolume;

	
	public Car (int fECity, int fEHwy, int sc, double cv) {
		fuelEconomyCity = fECity;
		fuelEconomyHwy = fEHwy;
		seatingCapacity = sc;
		cargoVolume = cv;
	}
	
		
	
	 public double getFEHwy() {
	 	return(14.3);
	 
	 }

	
	 public double getFECity() {
	 	return(6.8);
	 
	 }

	 public int getSeating() {
	 	return(5);
	 
	 }

	
	 public double getCargoVolume() {
	 	return(200);
	 }
}
	 
	 
