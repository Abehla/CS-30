public class Customer {
	private String firstName, lastName, street, city, state, zip;
		
	
	
	public Customer(String bill , String jones, String sesame, String calgary, String alberta, String T1X0Q1) {
		firstName = bill;
		lastName = jones;
		street = sesame;
		city = calgary;
		state = alberta;
		zip = T1X0Q1;
	}
	

	
	 public String toString() {
		String custString;
	
		custString = firstName + " " + lastName + "\n";
		custString += street + "\n";
		custString += city + ", " + state + "  " + zip + "\n";
	 	return(custString);
	}
}
