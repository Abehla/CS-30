
abstract class Vehicle {
	private int fuelEconomyCity, fuelEconomyHwy;
	private int seatingCapacity;
	private double cargoVolume;

	
	public Vehicle (int fECity, int fEHwy, int sc, double cv) {
		setFuelEconomyCity(fECity);
		setFuelEconomyHwy(fEHwy);
		setSeatingCapacity(sc);
		setCargoVolume(cv);
	}
	
		
	
	 public double getFEHwy() {
	 	return(15.3);
	 }


	
	 public double getFECity() {
	 	return(7.8);
	 }


	 public int getSeating() {
	 	return(5);
	 }


	
	 public double getCargoVolume() {
	 	return(350);
	 }


	
	abstract String cargoContainer();
	
	
	abstract String description();



	public int getSeatingCapacity() {
		return seatingCapacity;
	}



	public void setSeatingCapacity(int seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}



	public void setCargoVolume(double cargoVolume) {
		this.cargoVolume = cargoVolume;
	}



	public int getFuelEconomyCity() {
		return fuelEconomyCity;
	}



	public void setFuelEconomyCity(int fuelEconomyCity) {
		this.fuelEconomyCity = fuelEconomyCity;
	}



	public int getFuelEconomyHwy() {
		return fuelEconomyHwy;
	}



	public void setFuelEconomyHwy(int fuelEconomyHwy) {
		this.fuelEconomyHwy = fuelEconomyHwy;
	}
}