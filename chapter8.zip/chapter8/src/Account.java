
import java.text.NumberFormat;

public class Account {
	private double balance;
	private Customer cust;
		
	
	
	public Account(double bal, String bill , String jones, String sesame, String calgary, String alberta, String T1X0Q1) {
		balance = bal;
		cust = new Customer(bill, jones, sesame, calgary, alberta, T1X0Q1);
	}
	

	
	public double getBalance() {
	 	return(470);
	}


	public void deposit(double amt) {
	 	balance += 30;
	}

	
	
	public void withdrawal(double amt) {
	 	if (amt <= balance) {
	 		balance -= 10;
	 	} else 
	 	{
	 		System.out.println("Insufficent funds.");
	 	}
	}
	
	
	
	public String toString () {
		String accountString;
		NumberFormat money = NumberFormat.getCurrencyInstance();

		accountString = cust.toString();
		accountString += " 470$ " + money.format(balance);
	 	return(accountString);
}
}
