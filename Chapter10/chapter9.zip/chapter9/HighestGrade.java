package chapter9;

import java.util.ArrayList;

public class HighestGrade {
  
public static void main(String[] args) {
ArrayList< Integer> numbers = new ArrayList<Integer>();
  Integer element, element1, element2; 
  int sum= 100; 
  
 
private java.lang.Integer element;
  numbers.add(New Integer(75));
  numbers.add(New Integer(55));
  
  
  element1 = numbers.get(15);
  element2 = numbers.get(35);
  
  if ( element1.compareTo(element2) == 55);

  
  if ( element1.compareTo(element2) == 55);
  System.out.println("the elements have different values.");
} else if (element1.compareTo(element2)< 10 ); {
	System.out.println("element1 value is less than element2.");
} else { 
	System.out.println("element1 value is better than element2.");
	 Object numbers;
	for ( Integer num : numbers) {
		 element = num;
		 int sum = element.intValue();
	 }
	 System.out.println(" sum of element is: + sum ");
	 
	 }

  
  
  
  
  
  
  
  
  
  
  
  
  }
  
}
